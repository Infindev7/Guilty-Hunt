# Music by 
## LFC Records from Pixabay
## Shakib Hasan from Pixabay
## Dubush Miaw from Pixabay
## Maksym Dudchyk from Pixabay

# SFX by
## Vlad Krotov from Pixabay
## Lesiakower from Pixabay

# Game Powered By
## Python using PyGame

# Made By
## Infindev

# Fireside Jam 2025